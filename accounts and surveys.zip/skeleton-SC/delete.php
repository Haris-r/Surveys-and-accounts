<?php

require_once "header.php";

    if (!isset($_SESSION['loggedInSkeleton']))
{
	echo "You must be logged in to view this page.<br>";
}

    else{
        
        $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
        $sql = "DELETE FROM users WHERE username='$_GET[username]' ";
        
        if(mysqli_query($connection, $sql))
            header("refresh:1 url=admin.php");
        else
            echo "Not Deleted";
        }


?>