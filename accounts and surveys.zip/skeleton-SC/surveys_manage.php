<?php

// Things to notice:
// This is the page where each user can MANAGE their surveys
// As a suggestion, you may wish to consider using this page to LIST the surveys they have created
// Listing the available surveys for each user will probably involve accessing the contents of another TABLE in your database
// Give users options such as to CREATE a new survey, EDIT a survey, ANALYSE a survey, or DELETE a survey, might be a nice idea
// You will probably want to make some additional PHP scripts that let your users CREATE and EDIT surveys and the questions they contain
// REMEMBER: Your admin will want a slightly different view of this page so they can MANAGE all of the users' surveys

// execute the header script:
require_once "header.php";
require_once "credentials.php";


$showSurvey = true;


// checks the session variable named 'loggedInSkeleton'
// take note that of the '!' (NOT operator) that precedes the 'isset' function
if (!isset($_SESSION['loggedInSkeleton']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}




    if(isset($_POST['Submit'])){
$connection = mysqli_connect($dbhost, $dbuser, $dbpass , $dbname);
        
        
        if (!$connection)
{
	die("Connection failed: " . $mysqli_connect_error);
}
        
        
    $survey = "INSERT INTO questions
       (Question1,
        Question2,
        Question3,
        Question4,
        Question5) 
        VALUES ('{$_POST['q1']}',
        '{$_POST['q2']}',
        '{$_POST['q3']}',
        '{$_POST['q4']}',
        '{$_POST['q5']}')";
        
        $result = mysqli_query($connection, $survey);
         
        if ($result){
            echo 'survey submitted';
            echo "<br> <br>";
            echo "<a href='survey_table.php'> click here to check your submission";
            $showSurvey=false;
            mysqli_close($connection);
        
        }
        else {
            echo "<br>error inserting the details ";
        }
        
    }






/*
echo <<<_END
<form action='surveys_manage.php' method = 'post'>
_END;
    
$sql = "SELECT question FROM questions";
$sql2 = "SELECT answer FROM answers";



$result = mysqli_query($connection, $sql);
$result2 = mysqli_query($connection, $sql2);
	
	// how many rows came back? (can only be 1 or 0 because username is the primary key in our table):
$n = mysqli_num_rows($result);
   // $n = mysqli_num_rows($result2);

if($n>0){
    
    for($i=0; $i<$n; $i++){
    
    $row = mysqli_fetch_array($result);
    $question = $row['question'];
    echo $question.'<br>';
        
   
    $row2 = mysqli_fetch_array($result2);
    $answer = $row2['answer'];
    echo $answer.'<br>';
        
    }
    
    echo <<<_END
<input type = 'submit' name='submitResponse' value= 'submit'>
</form>
_END;

}

*/
	





 if($showSurvey){
    echo <<<_END
    
    <form  action "surveys_manage.php" method="post"><br>
      ANSWER THE FOLLOWING QUESTIONS:<br>
    
    <br>
      
      Who is your favourite FRIENDS character:<br>
      
      <select name="q1">
        <option value="Monica">Monica Geller</option>
        <option value="Chandler">Chandler Bing</option>
        <option value="Rachel">Rachel Green</option>
        <option value="Ross">Ross Geller</option>
        <option value="Joey">Joey Tribbiani</option>
        <option value="Phoebe">Phoebe Buffay</option>
      </select><br>
    
    <br>
    
      Who is your LEAST favourite FRIENDS character:<br>
      
      <select name="q2">
        <option value="Monica">Monica Geller</option>
        <option value="Chandler">Chandler Bing</option>
        <option value="Rachel">Rachel Green</option>
        <option value="Ross">Ross Geller</option>
        <option value="Joey">Joey Tribbiani</option>
        <option value="Phoebe">Phoebe Buffay</option>
      </select><br>
      
    <br>
    
    Which one of these is your favourite FRIENDS couple?<br>
    
    <input type="radio" name="q3" value="rr" /> Ross and Rachel
    <input type="radio" name="q3" value="mc" /> Monica and Chandler
    <input type="radio" name="q3" value="pm" /> Phoebe and Mike
    
    <br><br>
    
    Were Ross and Rachel on a break?<br>
    
    <input type="radio" name="q4" value="Yes" /> YES 
    <input type="radio" name="q4" value="No" /> NO
    
    <br><br>
    
    How many times have you watched the series FRIENDS?<br>
    
    <input type="number" name="q5" value="times" required>
    
    <br>

    <input type="submit" name="Submit" value="Submit">
    
    

    
    </form>	
    
_END;


    }






// finish off the HTML for this page:
require_once "footer.php";

?>