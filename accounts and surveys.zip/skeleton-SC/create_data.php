<?php

// Things to notice:
// This file is the first one we will run when we mark your submission
// Its job is to: 
// Create your database (currently called "skeleton", see credentials.php)... 
// Create all the tables you will need inside your database (currently it makes a simple "users" table, you will probably need more and will want to expand fields in the users table to meet the assignment specification)... 
// Create suitable test data for each of those tables 
// NOTE: this last one is VERY IMPORTANT - you need to include test data that enables the markers to test all of your site's functionality

// read in the details of our MySQL server:
require_once "credentials.php";

// We'll use the procedural (rather than object oriented) mysqli calls

// connect to the host:
$connection = mysqli_connect($dbhost, $dbuser, $dbpass);

// exit the script with a useful message if there was an error:
if (!$connection)
{
	die("Connection failed: " . $mysqli_connect_error);
}
  
// build a statement to create a new database:
$sql = "CREATE DATABASE IF NOT EXISTS " . $dbname;

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Database created successfully, or already exists<br>";
} 
else
{
	die("Error creating database: " . mysqli_error($connection));
}

// connect to our database:
mysqli_select_db($connection, $dbname);

///////////////////////////////////////////
////////////// USERS TABLE //////////////
///////////////////////////////////////////

// if there's an old version of our table, then drop it:
$sql = "DROP TABLE IF EXISTS users, questions";

// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Dropped existing table: users<br>
          Dropped existing table: feedback<br>
          Dropped existing table: answers<br>";
}

else 
{	
	die("Error checking for existing table: " . mysqli_error($connection));
}

// make our table:
// notice that the username field is a PRIMARY KEY and so must be unique in each record
$sql = "CREATE TABLE users (username VARCHAR(16), password VARCHAR(16), email VARCHAR(64), name VARCHAR(16), surname VARCHAR(16), DOB VARCHAR(10), telNum VARCHAR(11), PRIMARY KEY(username))";






// no data returned, we just test for true(success)/false(failure):
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: users<br>";
}

else 
{
	die("Error creating table: " . mysqli_error($connection));
}

// put some data in our table:
// create an array variable for each field in the DB that we want to populate

$usernames[] = 'barrym'; $passwords[] = 'letmein'; $emails[] = 'barry@m-domain.com'; $names[] = 'Barry'; $surnames[] = 'Mocha'; $DOBs[] = '31/03/2000'; $telNums[] = '07412345678';

$usernames[] = 'admin'; $passwords[] = 'secret'; $emails[] = 'admin@gmail.com'; $names[] = 'Admin'; $surnames[]= 'Admin'; $DOBs[] = '01/01/2000'; $telNums[] = '00000000000';

$usernames[] = 'mandyb'; $passwords[] = 'abc123'; $emails[] = 'webmaster@mandy-g.co.uk'; $names[] = 'Mandy'; $surnames[]= 'Bibi'; $DOBs[] = '14/11/2001'; $telNums[] = '01234567890';

$usernames[] = 'timmy'; $passwords[] = 'secret95'; $emails[] = 'timmy@lassie.com'; $names[] = 'Timmy'; $surnames[]= 'Turner'; $DOBs[]= '21/03/2009'; $telNums[]= '09876543210';

$usernames[] = 'briang'; $passwords[] = 'password'; $emails[] = 'brian@quahog.gov'; $names[] = 'Brian'; $surnames[]= 'Gabbar'; $DOBs[]= '09/05/1965'; $telNums[]= '11223344556';

$usernames[] = 'b'; $passwords[] = 'test'; $emails[] = 'b@alphabet.test.com'; $names[] = 'b'; $surnames[]= 'd'; $DOBs[]= '00/00/0000'; $telNums[]= '91919119991';
    
$usernames[] = 'c'; $passwords[] = 'test'; $emails[] = 'c@alphabet.test.com'; $names[] = 'c'; $surnames[]= 'o'; $DOBs[]= '00/00/0000'; $telNums[]= '91919191919';

$usernames[] = 'd'; $passwords[] = 'test'; $emails[] = 'd@alphabet.test.com'; $names[] = 'd'; $surnames[]= 'b'; $DOBs[]= '00/00/0000'; $telNums[]= '19199191991';



// loop through the arrays above and add rows to the table:
for ($i=0; $i<count($usernames); $i++)
{
	// create the SQL query to be executed
    $sql = "INSERT INTO users (username, password, email, name, surname, DOB, telNum) VALUES ('$usernames[$i]', '$passwords[$i]', '$emails[$i]', '$names[$i]', '$surnames[$i]', '$DOBs[$i]', '$telNums[$i]')";
	
	// run the above query '$sql' on our DB
    // no data returned, we just test for true(success)/false(failure):
	if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}

	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}

$Questions1[] = 'Monica';
$Questions2[] = 'Chandler';
$Questions3[] = 'rr';
$Questions4[] = 'Yes';
$Questions5[] = '2';



$sql = " CREATE TABLE questions(QuestionsID INT  NOT NULL AUTO_INCREMENT,

Question1 VARCHAR(128), 
Question2 VARCHAR(128), 
Question3 VARCHAR(128), 
Question4 VARCHAR(128), 
Question5 VARCHAR(128),
PRIMARY KEY(QuestionsID))";
    
if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: questions<br>";
}

else 
{
	die("Error creating table: " . mysqli_error($connection));
}



for($i=0; $i< count($Questions1); $i++){
    
    $sql = "INSERT INTO questions ( Question1, Question2, Question3, Question4, Question5) VALUES ('{$Questions1[$i]}', '{$Questions2[$i]}', '{$Questions3[$i]}', '{$Questions4[$i]}', '{$Questions5[$i]}')";
    
    if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}

	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}

}


/*


$sql = " CREATE TABLE questions ( QuestionsID INT NOT NULL AUTO_INCREMENT 
question1 VARCHAR(128),
question2 VARCHAR(128),
question3 VARCHAR(128),
question4 VARCHAR(128),
question5 VARCHAR(128),
PRIMARY KEY(QuestionsID))";


if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: Questions<br>";
}

else 
{
	die("Error creating table: " . mysqli_error($connection));
}


for ($i=0; $i<count($Questions1); $i++){
    
    $sql = "INSERT INTO questions ( question) VALUES ($Questions[$i]')";
    
    if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}

	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}

*/
/*
$sql = "CREATE TABLE answers(answersID INT NOT NULL AUTO_INCREMENT,
answer1 VARCHAR(512), 
answer2 VARCHAR(512),
answer3 VARCHAR(512),
answer4 VARCHAR(512),
answer5 VARCHAR(512),
PRIMARY KEY(answersID))";

if (mysqli_query($connection, $sql)) 
{
	echo "Table created successfully: answers<br>";
}

else 
{
	die("Error creating table: " . mysqli_error($connection));
}



    $answers1[]='answer';
    $answers2[]='answer';
    $answers3[]='answer';
    $answers4[]='answer';
    $answers5[]='answer';


for ($i=0; $i<count($answers1); $i++){
    
    
    $sql = "INSERT INTO answers (answer1, answer2, answer3, answer4, answer5) VALUES (
    '{$answers1[$i]}', 
    '{$answers2[$i]}', 
    '{$answers3[$i]}', 
    '{$answers4[$i]}', 
    '{$answers5[$i]}')";
    
    if (mysqli_query($connection, $sql)) 
	{
		echo "row inserted<br>";
	}

	else 
	{
		die("Error inserting row: " . mysqli_error($connection));
	}
}

*/
     
// we're finished, close the connection:
mysqli_close($connection);
?>