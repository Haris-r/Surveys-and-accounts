6G5Z2107 - 2CWK50 - 2019/20
<Haris Rafiq>
<18048968>


SETUP:
To initiate this website you must start with downloading xampp and installing it as well as a web development editor tool. 



DOCUMENTATION:
To start the user must initiate with the about.php page from there you can check out the sign up page to make a user account and access the surveys, then you have to log in to check the competitors out and to check a sample survey. The admin account has the username of admin and password as secret. The admin can delete accounts create accounts as well as updating them. The admin can also view the amount of users that submitted the surveys as well as the values of the submitted surveys within a table after submitting the survey himself.