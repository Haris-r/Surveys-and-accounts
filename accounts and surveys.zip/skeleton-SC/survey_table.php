<?php

require_once "header.php";

if (!isset($_SESSION['loggedInSkeleton']))
{
    echo "You must be logged in to view this page.<br>";
}

else
{
    
 
    
    if ($_SESSION['username'] == "admin")
    {
        
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}
    
    $sql = "SELECT Question1, Question2, Question3, Question4, Question5 FROM questions";
    $result= mysqli_query($connection, $sql);
   
    
    $answer = mysqli_num_rows($result);
        
    if ($answer>0)
	
	{
            
        //$row = mysqli_fetch_assoc($result);
		echo "<table width= '700'>
        
        <tr>
        
            <th> Who is your favourite FRIENDS character: </th>
            <th> Who is your LEAST favourite FRIENDS character: </th>
            <th> Which one of these is your favourite FRIENDS couple? </th>
            <th> Were Ross and Rachel on a break? </th>
            <th> How many times have you watched the series FRIENDS? </th>  
            
       </tr>";
            
        while($row = mysqli_fetch_array($result)){
                
                echo "<tr>";
                
             
                echo "<td>" . $row['Question1'] . "</td>";
                echo "<td>" . $row['Question2'] . "</td>";
                echo "<td>" . $row['Question3'] . "</td>";
                echo "<td>" . $row['Question4'] . "</td>";
                echo "<td>" . $row['Question5'] . "</td>";
                
                echo "</tr>";
                
            }
        echo "<tr> <td> The total number of respondents are: <br> <b>$answer</b></td></tr>";
        
        echo "</table>";
        
    }
        

    
	else
	{
		echo "You don't have permission to view this page...<br>";
	}
    
        

    
}

    
}
require_once "footer.php";
include 'css assignment.css';
?>