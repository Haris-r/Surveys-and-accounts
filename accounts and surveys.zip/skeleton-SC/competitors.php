<?php

// Things to notice:
// You need to add your Analysis and Design element of the coursework to this script
// There are lots of web-based survey tools out there already.
// It’s a great idea to create trial accounts so that you can research these systems. 
// This will help you to shape your own designs and functionality. 
// Your analysis of competitor sites should follow an approach that you can decide for yourself. 
// Examining each site and evaluating it against a common set of criteria will make it easier for you to draw comparisons between them. 
// You should use client-side code (i.e., HTML5/JavaScript/jQuery) to help you organise and present your information and analysis 
// For example, using tables, bullet point lists, images, hyperlinking to relevant materials, etc.

// execute the header script:
require_once "header.php";

// checks the session variable named 'loggedInSkeleton'
// take note that of the '!' (NOT operator) that precedes the 'isset' function
if (!isset($_SESSION['loggedInSkeleton']))
{
	// user isn't logged in, display a message saying they must be:
	echo "You must be logged in to view this page.<br>";
}

// the user must be signed-in, show them suitable page content
else
{
	echo "<h2>Analysis and Design</h2>
    
Within this section of the assignment, I will be comparing different type of surveys across the internet, mainly the more suitable competitors and analyse them in terms of their: login process, layout, ease of use, their question types and the analysis tool.

<br>
<br>

The first website we will be looking at is <a href = https://www.surveymonkey.com/>Survey Monkey</a>

<img src= 'MS_image.png' />

<h3>Layout of surveys</h3>

<p>

There are three ways in which the survey monkey presents their surveys. The first method is where a user can create a multiple-choice survey that fits in one page and the user who would answer the survey can choose between five answers. The second method in which you can layout a survey would be when each question is presented at a time, which means that before proceeding to the next question the user must first answer the question shown on the screen and after answering that the user can then proceed to the next question, this allows the user to focus on each question at once so they can really focus on each question. The last type of service provided by Survey Monkey is a live-chat type of option where the user can engage in a conversation with the SurveyMonkey Genius who will then ask question, in this format the user can feel more involved in completing the survey and can get a better feedback.</p>

<br>

<h3>Ease of use</h3>

<p>
The developers of Survey Monkey made their website very user friendly, so that people that are good at developing professional surveys as well as users that are new to this field can easily create the type of survey they want to make. Before creating a survey, the user has the option to choose if they want a survey created for them based upon a few question the website will ask, or if they want to start from a blank page and start their own personalised survey from scratch for the more professional users. My opinion of their ease to use is that it’s exceptional that the Survey has an option of creating a survey for the less experienced users, however they could have an option where there is a layout which they can choose in ask the questions they have in mind for users who want to create a survey with their own questions, but also do not want to spend a lot of time on designing the layout.</p>

<br>

<h3>Log-in process</h3>

<p>
The log in process of this website is very similar to other website, in order to register a user must enter a creative username, followed by a password, an email address as well as first and last name as shown in the screenshot by the side. There is also an option for the user to signup via their social media. I would like to critique the fact that Survey Monkey requires very few details in order to register a user. I would rather ask for more details to validate a user to make sure, the users cannot spam such as asking for their telephone number and make sure they are old enough by asking their data of birth as it can be relevant, however they do ask for more information once a user is registered so that surveys are better suited for that specific user. </p>

<br>

<h3>Question Types</h3>

<p>
There are a lot of different ways that Survey Monkey has presented the type of questions a user can ask, such as the basic options such as check boxes  and dropdown menus between questions for multiple choice type of surveys, or a comment box or single text box for questions that are more openminded and need more details so that the user doesn’t feel they are stuck between a few options. There are also more dynamic options like rating type of questions in which the user can use the stars to rate certain statement type of surveys or rate opinions of a creator. The survey monkey has far too many types of question to be compared to my website, however I will be using some of these options in consideration.</p>

<br>

<h3> Analysis Tools </h3>

<p>
There are two ways in which survey monkey analyses the data that the users have inputted after completing the survey, the first method is simply a summary of how many people have chosen which options and these can be outputted simply in data or bar charts to see which were the most popular choices. This method of outputting the analysis result is very effective because the user can easily get a feedback. Another analysis allows the user to assess answers from each person who undertook the survey to check their answers in more details instead of having an over overview from each and every person who has undertook the survey.</p>

<br>
<br>


The second website we will be evaluating is <a href = https://www.google.com/forms/about/>Google Forms</a>

<img src= 'google_forms.png' />

    
<h3> Layout of surveys </h3>

<p> The layout for google surveys is more dynamic compared to the Survey Monkey surveys.  This is because the user has more options to set up and design the layout of their surveys in terms of simple things such as changing the presentation of it. There are many more options to customise your survey using google forms, such as having a different font-style. Changing the background colour or make the header stand out more is another unique aspect of google forms which the Survey Monkey does not have. This is a good option since the users have a way to make their surveys stand out more and be more eye-catching compared to other user’s surveys according to their own likings. </p>

<h3> Ease of Use </h3>

<p>Google forms is a more user-friendly website compared to the Survey Monkey, as it is easier for a user to customise and lay out their surveys easily using its tools to design them as they are very straightforward. However, unlike the Survey Monkey, there is not an option to make a survey automatically by asking the user some questions within Google Forms which is a better advanced feature within Survey Monkey compared to Google Forms. Within the Google Forms a user can however choose between premade templates and themes to use for their own customizable surveys. The two features that google forms offers are, professional and personal categories of survey so that the user can decide if they want to make their survey in a professional manner for work and use advanced featured for developers or if they want to make it for their personal use and only use the most basic and simple features of Google Form.</p>

<br>

<h3>Log-in process</h3>

<p>To sign up for Google Forms and access it, the user must create a Gmail account. These days to access or sign-up for most websites a user must need a google account. Tu register a user must simply insert their first name, surname, username for their email address which has to be unique and a password. This is very similar to the Survey Monkey’s log in system as it requires very few details in order for the user to register and log-in. In comparison for my own website I will make sure that I ask more details from the user to get to know who is getting registered and if they are valid to register and access the features within my web page compared to my competitors. </p>

<br>

<h3>Question Types</h3>

<p>
There are some similarities between the Survey Monkey and Google Forms websites, one of which is the amount of question types the user can choose from to create their own survey.  There are many types of question options you can choose from Survey Monkey, however Google Forms offers more of a variety such as date and time features as well as linear scale where the user can choose to create questions on scale. With this question type within Google Forms the user can feel like they have a variety of scale to choose from instead just one checkbox. This is a very good option which is unique in Google Forms and I look forward to implementing that in my own websites.</p>

<br>

<h3> Analysis Tools </h3>

<p>The analysis tools of Google Forms are used worldwide from smaller businesses and a lot of developers. These tools let the user analyse all the questions answered by their users in a summarized way with different bar charts and pie charts. A lot of the results use percentages such as the pie chart outputs its keys and it is structured so that after a consumer answered the question to a survey they will be summed up and converted as a percentage to output the results for the end user. The Google Form also allows the user to download a spreadsheet which includes the sum of the users and the answers they have chosen from the survey for the user to better analyse the responses from the result of their questionnaire. The way Google Forms displays different sorts of charts to analyse the responses of their questionnaire is an inspiration for my own website and I will be making sure to use similar tools for my own.</p>

<br>

<p>Overall, I think the advantage that Google Forms has over the Survey Monkey is that it’s a free survey maker that users can use to be creative with. Whereas for Survey Maker the user has to purchase a monthly subscription.</p>

<br>
<br>

The third and last website we will be evaluating as a competitor is <a href = https://surveyplanet.com/> Survey Planet </a>

<img src= 'survey_planet.png' />

<h3> Layout of surveys </h3>

<p> Survey planet offers a lot more categories in terms of designs and the layout of the surveys compared to websites such as Google Forms and Survey Monkey. However, the drawback of this is that the designs cannot be edited by the user which means the user must only use the themes already set by survey planet unlike Google Forms which allows the user to be more creative with their designs. The designs and themes offered by Survey Planet are 35 so there is a variety, however they are very basic. The advantage of these surveys being fixed is that the layouts of the designs are mostly professional and can be viewed from different devices and keep its professionalism. </p>

<h3> Ease of Use </h3>

<p>Survey Planet is very user-friendly in terms the way it is designed so that the users do not struggle to navigate to where the way they want to use the website. The navigation bar is very simple, and it also has the guide page which helps users find out how the website works and guides them step by step so that if the user is not fully friendly within this environment. This page includes help for people who have basic questions on how most functions operate and answers most frequently asked questions in which a user might struggle. Compared to the Survey Monkey and Google Forms the planet survey is an easier option to use.</p>

<br>

<h3>Log-in process</h3>

<p>Compared to Survey Monkey and Google Forms the Survey Planet asks fewer details such as the full name, email address and just to set a password. There is also a ‘I am not a robot’ test or process to follow to prevent spam accounts to be created. After creating the account, the user must also confirm their email address by going their own accounts. </p>

<br>

<h3>Question Types</h3>

<p>
The type of questions that Survey Planet offers are similar to the surveys other survey websites such as its competitors like Survey Monkey and Google Forms. However, there are some unique question types that none of its competitors offer and are exclusive to survey planet which gives it an edge, such as the forms. This is an interesting addition to this website as it allows the user to create a whole question with different options. There is another exclusive feature such as the images options, however we have met this feature before in the Survey Monkey website.</p>

<br>

<h3> Analysis Tools </h3>

<p>The analysis tools within Survey Planet are also similar to the Google Forms tools which allows the end-user to see the overview and the summary of all the respondents so then he or she can analyse them. Basic pie charts are used to display results as a percentage, this allows the user to see which question has received which answer. The total number of submissions is also submitted, and the sum is displayed, I will be using this option within my own website so that the admin can check how many users have chosen which options.</p>

<br>

<p>In conclusion, I think the Survey Planet has a suitable analysis tool which I can implement within my own site however compared to the other two websites it has limited options as they exceed in terms of professional users as well as developers’ expectations.</p>

<br>
<br>


    
    
";    
}

// finish off the HTML for this page:
require_once "footer.php";
?>