<?php

// Things to notice:
// You need to add code to this script to implement the admin functions and features
// Notice that the code not only checks whether the user is logged in, but also whether they are the admin, before it displays the page content
// When an admin user is verified, you can implement all the admin tools functionality from this script, or distribute them over multiple pages - your choice

// execute the header script:
require_once "header.php";

// checks the session variable named 'loggedInSkeleton'
// take note that of the '!' (NOT operator) that precedes the 'isset' function


 




if (!isset($_SESSION['loggedInSkeleton']))
{
    echo "You must be logged in to view this page.<br>";
}

 

//the user must be signed-in, show them suitable page content
else
{
    if ($_SESSION['username'] == "admin")
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
	
	// if the connection fails, we need to know, so allow this exit:
	if (!$connection)
	{
		die("Connection failed: " . $mysqli_connect_error);
	}	
	
    $sql = "SELECT * FROM users";
    $result= mysqli_query($connection, $sql);
	//only display the page content if this is the admin account (all other users get a "you don't have permission..." message):
    
    
    $answer = mysqli_num_rows($result);
        
        if ($answer>0)
	
	{
		echo "<table width= '700'> 
            
            <tr>
            
            <th> Usernames </th>
            <th> password </th>
            <th> first name </th>
            <th> last name </th>
            <th> E-mail address </th>
            <th> Date of Birth </th>
            <th> Telephone Number </th>
            <th> Update </th>
            <th> Create new User </th>
            <th> Delete </th>
            
            
            
            </tr>";
                
        while($row = mysqli_fetch_array($result)){
            
            $username = $row['username'];
            
            echo " <tr>";
            
            echo "<td>".$row['username']."</td>";
            echo "<td>".$row['password']."</td>";
            echo "<td>".$row['email']."<s/td>";
            echo "<td>".$row['name']."</td>";
            echo "<td>".$row['surname']."</td>";
            echo "<td>".$row['DOB']."</td>";
            echo "<td>".$row['telNum']."</td>";
            
            echo "<td><a href ='account_set.php?username=$username'>Update</td>";
            echo "<td><a href ='sign_up.php'> Create new account</td>";
            echo "<td><a href ='delete.php?username=$username'>delete</td>";
            
            echo"</tr>";
        }
        echo"</table>";
                
            
       // "Implement the admin tools here... See the assignment specification for more details.<br>";
	}

	else
	{
		echo "You don't have permission to view this page...<br>";
	}
}

// finish off the HTML for this page:

require_once "footer.php";
include 'css assignment.css';
?>