<?php

// Things to notice:
// This script holds the sanitisation function that we pass all our user data to
// This script holds the validation functions that double-check our user data is valid
// You can add new PHP functions to validate different kinds of user data (e.g., emails, dates) by following the same convention:
// if the data is valid return an empty string, if the data is invalid return a help message
// You are encouraged to create/add your own PHP functions here to make frequently used code easier to handle



// function to sanitise (clean) user data:
function sanitise($str, $connection)
{
	if (get_magic_quotes_gpc())
	{
		// just in case server is running an old version of PHP with "magic quotes" running:
		$str = stripslashes($str);
	}

	// escape any dangerous characters, e.g. quotes:
	$str = mysqli_real_escape_string($connection, $str);
	// ensure any html code is safe by converting reserved characters to entities:
	$str = htmlentities($str);
	// return the cleaned string:
	return $str;
}





// if the data is valid return an empty string, if the data is invalid return a help message
function validateString($field, $minlength, $maxlength) 
{
    if (strlen($field)<$minlength) 
    {
		// wasn't a valid length, return a help message:		
        return "Minimum length: " . $minlength; 
    }

	elseif (strlen($field)>$maxlength) 
    { 
		// wasn't a valid length, return a help message:
        return "Maximum length: " . $maxlength; 
    }

	// data was valid, return an empty string:
    return ""; 
}





// if the data is valid return an empty string, if the data is invalid return a help message
function validateInt($field, $min, $max) 
{ 
	// see PHP manual for more info on the options: http://php.net/manual/en/function.filter-var.php
	$options = array("options" => array("min_range"=>$min,"max_range"=>$max));
    
	if (!filter_var($field, FILTER_VALIDATE_INT, $options)) 
    { 
		// wasn't a valid integer, return a help message:
        return "Not a valid number (must be whole and in the range: " . $min . " to " . $max . ")"; 
    }
	// data was valid, return an empty string:
    return ""; 
}


function validateMail($field){
    $field = filter_var($field, FILTER_VALIDATE_EMAIL);
    
    if(filter_var($field, FILTER_VALIDATE_EMAIL)){
        return'';
    }
    else
    {
        return 'invalid email';
    }
}

function validateDate($field)
{
    
    $date = explode("-", $field);
    if(count($date)== 3)
    {
    
    if(!checkdate($date[1], $date[2], $date[0]))
        {
            return "wrong date of birth";
        }
    else
        {
            return "";
        }
    }
}



function validateTelNum($field){
    
    $counter= 0;
    
    for($i=0; $i<strlen($field); $i++){
    
    if($field[$i] != "0" && 
       $field[$i] != "1" && 
       $field[$i] != "2" && 
       $field[$i] != "3" && 
       $field[$i] != "4" && 
       $field[$i] != "5" && 
       $field[$i] != "6" && 
       $field[$i] != "7" && 
       $field[$i] != "8" && 
       $field[$i] != "9" && 
       $field[$i] != "+")
        {
        
        $counter++;
        
       }
    }
    
    if ($counter > 0 || strlen($field) > 14){
        return "your phone number is incorrect";
    }
    else{
        return"";
        $counter =0;
    }
        
   
}

// all other validation functions should follow the same rule:
// if the data is valid return an empty string, if the data is invalid return a help message
// ...

?>